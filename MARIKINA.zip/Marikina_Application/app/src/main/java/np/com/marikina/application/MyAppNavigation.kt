package np.com.marikina.application

import BfpForm
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import np.com.marikina.application.admin.AdminHomeScreen
import np.com.marikina.application.admin.DashboardScreen
import np.com.marikina.application.admin.UserAnalyticsPage
import np.com.marikina.application.auth.AuthViewModel
import np.com.marikina.application.pages.LoginPage
import np.com.marikina.application.pages.SignupPage
import np.com.marikina.application.users.HistoryPage
import np.com.marikina.application.users.HomePage
import np.com.marikina.application.users.ProfilePage
import np.com.marikina.application.users.RescueForm

class MyAppNavigation : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val navController = rememberNavController()
            val authViewModel = AuthViewModel()
            val auth = FirebaseAuth.getInstance()
            val database = FirebaseDatabase.getInstance().reference

            var isAdmin by remember { mutableStateOf<Boolean?>(null) }
            var isLoggedIn by remember { mutableStateOf(auth.currentUser != null) }
            val coroutineScope = rememberCoroutineScope()

            // ✅ Fetch user role from Firebase kapag nakalog-in
            LaunchedEffect(isLoggedIn) {
                if (isLoggedIn) {
                    auth.currentUser?.let { user ->
                        coroutineScope.launch {
                            try {
                                val snapshot = database.child("users").child(user.uid).get().await()
                                isAdmin = snapshot.child("isAdmin").value.toString().toBoolean()
                            } catch (e: Exception) {
                                isAdmin = false
                            }
                        }
                    } ?: run {
                        isAdmin = false
                    }
                }
            }

            // ✅ Hintayin ang `isAdmin` bago i-load ang navigation
            if (isAdmin == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                NavHost(navController, startDestination = if (isLoggedIn) "home" else "login") {
                    composable("login") { LoginPage(navController, authViewModel) }
                    composable("signup") { SignupPage(navController, authViewModel) }

                    // ✅ Admin o User Dashboard
                    composable("home") {
                        if (isAdmin == true) {
                            AdminHomeScreen(navController, authViewModel)
                        } else {
                            HomePage(navController, authViewModel)
                        }
                    }

                    // ✅ Profile Page na may dynamic userId
                    composable("profile/{userId}") { backStackEntry ->
                        val userId = backStackEntry.arguments?.getString("userId") ?: ""
                        ProfilePage(navController,userId)
                    }
                    composable("dashboard") { DashboardScreen(navController) } // ✅ Tama na

                    composable("rescue_161_form") { RescueForm(navController) }
                    composable("bfp_form") { BfpForm(navController, authViewModel) }
                    composable("history") { HistoryPage(navController, authViewModel) }

                    // ✅ User Analytics at Dashboard
                    composable("user_analy") { UserAnalyticsPage(navController) }

                }
            }
        }
    }
}
