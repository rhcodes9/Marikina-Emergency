
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.android.gms.location.LocationServices
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import np.com.bimalkafle.firebaseauthdemoapp.R
import np.com.marikina.application.auth.AuthViewModel
import np.com.marikina.application.users.fetchCurrentLocation
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BfpForm(navController: NavController, authViewModel: AuthViewModel) {
    val context = LocalContext.current
    val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return
    val database = FirebaseDatabase.getInstance().reference.child("rescue_request")
    val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)

    var fullName by remember { mutableStateOf("") }
    var contactNumber by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("Fetching location...") }
    var selectedHotline by remember { mutableStateOf("Select Hotline") }
    var hotlineExpanded by remember { mutableStateOf(false) }
    var customHotline by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }

    val hotlines = listOf("Smart" to "911", "Globe" to "9292929", "TNT" to "8888", "Custom Hotline" to "")

    // Fetch user details from Firebase
    LaunchedEffect(userId) {
        FirebaseDatabase.getInstance().reference.child("users").child(userId).get()
            .addOnSuccessListener { snapshot ->
                fullName = snapshot.child("fullName").value?.toString() ?: ""
                contactNumber = snapshot.child("contactNumber").value?.toString() ?: ""
                fetchCurrentLocation(context, fusedLocationClient) { address -> location = address }
            }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("BFP Emergency Form", color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = Color.Red)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.bfp),
                contentDescription = "BFP Image",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .padding(bottom = 5.dp)
            )

            OutlinedTextField(value = fullName, onValueChange = { fullName = it }, label = { Text("Full Name") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = contactNumber, onValueChange = { contactNumber = it }, label = { Text("Contact Number") }, modifier = Modifier.fillMaxWidth())

            OutlinedTextField(
                value = location,
                onValueChange = { location = it },
                label = { Text("Current Address") },
                trailingIcon = {
                    IconButton(onClick = { fetchCurrentLocation(context, fusedLocationClient) { address -> location = address } }) {
                        Icon(Icons.Filled.LocationOn, contentDescription = "Get Location", tint = Color.Red)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = selectedHotline,
                    onValueChange = {},
                    label = { Text("Select Hotline") },
                    readOnly = true,
                    trailingIcon = {
                        Icon(Icons.Filled.ArrowDropDown, contentDescription = "Dropdown", Modifier.clickable { hotlineExpanded = true })
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                DropdownMenu(expanded = hotlineExpanded, onDismissRequest = { hotlineExpanded = false }) {
                    hotlines.forEach { (label, _) ->
                        DropdownMenuItem(
                            text = { Text(label) },
                            onClick = {
                                selectedHotline = label
                                hotlineExpanded = false
                                if (label != "Custom Hotline") customHotline = ""
                            }
                        )
                    }
                }
            }

            if (selectedHotline == "Custom Hotline") {
                OutlinedTextField(
                    value = customHotline,
                    onValueChange = { customHotline = it },
                    label = { Text("Enter Custom Hotline") },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Button(
                onClick = {
                    val numberToCall = if (selectedHotline == "Custom Hotline") customHotline else hotlines.find { it.first == selectedHotline }?.second
                    numberToCall?.takeIf { it.isNotBlank() }?.let { startPhoneCall(context, it) }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD50000))
            ) {
                Text("📞 Call Now", color = Color.White)
            }

            Button(
                onClick = {
                    if (fullName.isEmpty() || contactNumber.isEmpty() || location.isEmpty() || selectedHotline == "Select Hotline" ||
                        (selectedHotline == "Custom Hotline" && customHotline.isBlank())
                    ) {
                        Toast.makeText(context, "Please fill all fields", Toast.LENGTH_SHORT).show()
                        return@Button
                    }

                    isSubmitting = true
                    val reportId = database.push().key ?: return@Button
                    val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

                    val hotlineNumber = if (selectedHotline == "Custom Hotline") customHotline else hotlines.find { it.first == selectedHotline }?.second ?: "911"

                    val formData = mapOf(
                        "reportId" to reportId,
                        "userId" to userId,
                        "fullName" to fullName,
                        "contactNumber" to contactNumber,
                        "location" to location,
                        "hotline" to hotlineNumber,
                        "category" to "BFP",
                        "timestamp" to timestamp,
                        "status" to "On the Way"
                    )

                    database.child(reportId).setValue(formData).addOnCompleteListener { task ->
                        isSubmitting = false
                        if (task.isSuccessful) {
                            Toast.makeText(context, "BFP Report Sent!", Toast.LENGTH_LONG).show()
                            navController.navigate("home") {
                                popUpTo(0) { inclusive = true } // Clear backstack
                                launchSingleTop = true
                            }
                        } else {
                            Toast.makeText(context, "Error submitting report", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0288D1))
            ) {
                Text("Submit BFP Report", color = Color.White)
            }
        }
    }
}

private fun startPhoneCall(context: Context, phoneNumber: String) {
    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
    context.startActivity(intent)
}
