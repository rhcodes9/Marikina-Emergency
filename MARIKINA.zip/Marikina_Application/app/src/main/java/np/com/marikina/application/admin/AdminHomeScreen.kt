package np.com.marikina.application.admin

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DashboardCustomize
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.launch
import np.com.marikina.application.auth.AuthViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminHomeScreen(navController: NavController?, authViewModel: AuthViewModel) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            AdminNavigationDrawer(navController, authViewModel) {
                scope.launch { drawerState.close() }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(
                                    imageVector = Icons.Default.Menu,
                                    contentDescription = "Menu",
                                    tint = Color.White,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Admin Marikina Emergency", fontSize = 20.sp, color = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFD50000))
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {Spacer(modifier = Modifier.height(300.dp))

                // ✅ USER GREETING (FETCHED FULL NAME)
                val fullName = ""
                Text(
                    text = "Stay ready, Admin $fullName!", // 🔥 FETCHED FULL NAME
                    color = Color.Black,
                    fontSize = 30.sp, // ✅ Adjust size
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(25.dp))

                // ✅ Emergency Message (Pantay at isang linya lang)
                Text(
                    text = "When disaster strikes, your leadership guides Marikina to safety.",
                    color = Color.DarkGray,
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun AdminRequestsList() {
    val database = FirebaseDatabase.getInstance().reference.child("admin_requests")
    var requests by remember { mutableStateOf(emptyList<Pair<String, String>>()) }

    LaunchedEffect(Unit) {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                requests = snapshot.children.mapNotNull {
                    val userId = it.key
                    val email = it.child("email").value.toString()
                    userId?.let { uid -> uid to email }
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    Column {
        Text("", fontSize = 20.sp)
        requests.forEach { (userId, email) ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .background(Color.Gray, shape = RoundedCornerShape(8.dp))
                    .clickable {
                        FirebaseDatabase.getInstance().reference.child("users")
                            .child(userId).child("isAdmin").setValue(true)
                        database.child(userId).removeValue()
                    }
                    .padding(16.dp)
            ) {
                Text(email, fontSize = 16.sp, color = Color.White)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminNavigationDrawer(
    navController: NavController?,
    authViewModel: AuthViewModel,
    closeDrawer: () -> Unit
) {
    ModalDrawerSheet {
        // ✅ Marikina Logo (Gamit ang Local Drawable Image)
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = rememberAsyncImagePainter("https://marikina.gov.ph/images/seal1.png"),
                contentDescription = "Marikina Logo",
                modifier = Modifier
                    .size(200.dp)
                    .padding(top = 16.dp)
            )
            Text("ADMIN MARIKINA EMERGENCY", fontSize = 20.sp, modifier = Modifier.padding(8.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))
        NavigationItem("Dashboard", Icons.Default.DashboardCustomize, "dashboard", navController, closeDrawer)
        Spacer(modifier = Modifier.weight(1f))
        NavigationItem("Logout", Icons.Default.ExitToApp, "", navController, closeDrawer) {
            authViewModel.logout(navController!!)
        }
    }
}

@Composable
fun NavigationItem(
    title: String,
    icon: ImageVector,
    route: String,
    navController: NavController?,
    closeDrawer: () -> Unit,
    action: (() -> Unit)? = null
) {
    NavigationDrawerItem(
        icon = { Icon(icon, contentDescription = title) },
        label = { Text(title) },
        selected = false,
        onClick = {
            if (action != null) {
                action()
            } else if (route.isNotEmpty()) {
                navController?.navigate(route)
            }
            closeDrawer()
        },
        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
    )
}
