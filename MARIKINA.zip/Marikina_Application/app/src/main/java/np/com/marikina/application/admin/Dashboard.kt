package np.com.marikina.application.admin

import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.util.Calendar

data class User(
    val id: String = "",
    var fullName: String = "Unknown",
    var location: String = "No Location",
    var category: String = "161",
    var contactNumber: String = "Unknown",
    var status: String = "Pending",
    val dateSubmitted: String = "",
    var age: String = "",
    var address: String = "",
    val email: String = ""
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(navController: NavController) {
    val users = remember { mutableStateListOf<User>() }
    val database = FirebaseDatabase.getInstance().getReference("rescue_request")
    val context = LocalContext.current

    var selectedDate by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }

    LaunchedEffect(selectedDate) {
        fetchUsers(database, context) { fetchedUsers ->
            users.clear()
            val sorted = fetchedUsers.sortedByDescending { it.dateSubmitted }
            users.addAll(sorted)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Dispatcher View", color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFD32F2F))
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    label = { Text("Search") },
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 8.dp)
                )

                Button(
                    onClick = {
                        showDatePicker(context) { date -> selectedDate = date }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Gray),
                    modifier = Modifier.padding(bottom = 10.dp)
                ) {
                    Text(
                        if (selectedDate.isEmpty()) "Select Date" else "Date: $selectedDate",
                        color = Color.White,
                        fontSize = 12.sp
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp)
            ) {
                Text("Full Name", modifier = Modifier.weight(1f), fontSize = 14.sp)
                Text("Location", modifier = Modifier.weight(1f), fontSize = 14.sp)
                Text("Category", modifier = Modifier.weight(1f), fontSize = 14.sp)
                Text("Status", modifier = Modifier.weight(1f), fontSize = 14.sp)
            }

            Divider()

            val filteredUsers = users.filter { user ->
                (selectedDate.isEmpty() || user.dateSubmitted == selectedDate) &&
                        (searchQuery.isEmpty() || user.fullName.contains(searchQuery, true)
                                || user.location.contains(searchQuery, true)
                                || user.category.contains(searchQuery, true)
                                || user.status.contains(searchQuery, true))
            }

            LazyColumn {
                items(filteredUsers) { user ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(7.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            user.fullName,
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    navController.navigate("profile/${user.id}")
                                },
                            fontSize = 12.sp
                        )

                        Text(
                            text = "View Map",
                            color = Color.Blue,
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    openMapWithETA(context, user.location)
                                },
                            fontSize = 12.sp
                        )

                        Text(
                            user.category,
                            modifier = Modifier.weight(1f),
                            fontSize = 12.sp
                        )

                        EmergencyStatusButton(user = user, database = database) { newStatus ->
                            val index = users.indexOfFirst { it.id == user.id }
                            if (index != -1) {
                                users[index] = users[index].copy(status = newStatus)
                            }
                        }
                    }
                    Divider()
                }
            }
        }
    }
}

fun fetchUsers(
    database: DatabaseReference,
    context: Context,
    onResult: (List<User>) -> Unit
) {
    database.addListenerForSingleValueEvent(object : ValueEventListener {
        override fun onDataChange(snapshot: DataSnapshot) {
            val userList = mutableListOf<User>()
            snapshot.children.forEach { reportSnapshot ->
                try {
                    val userMap = reportSnapshot.value as? Map<*, *> ?: return@forEach
                    val user = User(
                        id = reportSnapshot.key.orEmpty(),
                        fullName = userMap["fullName"] as? String ?: "Unknown",
                        location = userMap["location"] as? String ?: "No Location",
                        category = userMap["category"] as? String ?: "161",
                        contactNumber = userMap["contactNumber"] as? String ?: "Unknown",
                        status = userMap["status"] as? String ?: "Pending",
                        dateSubmitted = userMap["dateSubmitted"] as? String ?: "",
                        address = userMap["address"] as? String ?: "Unknown",
                        age = userMap["age"] as? String ?: "Unknown",
                        email = userMap["email"] as? String ?: "Unknown"
                    )
                    userList.add(user)
                } catch (e: Exception) {
                    Log.e("Firebase", "Error parsing user: ${e.message}")
                    Toast.makeText(context, "Error loading data: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            onResult(userList)
        }

        override fun onCancelled(error: DatabaseError) {
            Log.e("Firebase", "Database read failed: ${error.message}")
            Toast.makeText(context, "Failed to load data.", Toast.LENGTH_LONG).show()
        }
    })
}

@Composable
fun EmergencyStatusButton(
    user: User,
    database: DatabaseReference,
    onStatusUpdated: (String) -> Unit
) {
    val statusColor = when (user.status) {
        "Pending" -> Color(0xFFD32F2F)
        "On the Way" -> Color(0xFFFF9800)
        "Resolved" -> Color(0xFF388E3C)
        else -> Color.Gray
    }

    Button(
        onClick = {
            val newStatus = when (user.status) {
                "Pending" -> "On the Way"
                "On the Way" -> "Resolved"
                else -> "Pending"
            }

            database.child(user.id).child("status").setValue(newStatus)
                .addOnSuccessListener {
                    onStatusUpdated(newStatus)
                }
                .addOnFailureListener {
                    Log.e("StatusUpdate", "Failed to update status: ${it.message}")
                }
        },
        colors = ButtonDefaults.buttonColors(containerColor = statusColor),
    ) {
        Text(text = user.status, color = Color.White, fontSize = 12.sp)
    }
}

fun showDatePicker(context: Context, onDateSelected: (String) -> Unit) {
    val calendar = Calendar.getInstance()
    DatePickerDialog(
        context,
        { _, year, month, dayOfMonth ->
            val formattedDate = String.format("%02d/%02d/%04d", dayOfMonth, month + 1, year)
            onDateSelected(formattedDate)
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    ).show()
}

fun openMapWithETA(context: Context, destination: String) {
    val gmmIntentUri = Uri.parse("google.navigation:q=${Uri.encode(destination)}")
    val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
    mapIntent.setPackage("com.google.android.apps.maps")

    if (mapIntent.resolveActivity(context.packageManager) != null) {
        context.startActivity(mapIntent)
    } else {
        Toast.makeText(context, "Google Maps not found", Toast.LENGTH_SHORT).show()
    }
}
