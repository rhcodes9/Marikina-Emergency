package np.com.marikina.application.users

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.FireExtinguisher
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.DrawerState
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import np.com.bimalkafle.firebaseauthdemoapp.R
import np.com.marikina.application.auth.AuthViewModel

/* ---------------- HOME PAGE ---------------- */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomePage(navController: NavController, authViewModel: AuthViewModel) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val database = FirebaseDatabase.getInstance().reference
    val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return

    var fullName by remember { mutableStateOf("Guest") }
    var showTutorial by remember { mutableStateOf(false) }

    LaunchedEffect(userId) {
        database.child("users").child(userId).child("fullName").get()
            .addOnSuccessListener {
                fullName = it.value?.toString() ?: "Guest"
            }
    }

    if (showTutorial) {
        TutorialStepsOverlay { showTutorial = false }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            NavigationDrawer(
                navController,
                authViewModel,
                drawerState,
                userId
            ) { showTutorial = true }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Marikina Emergency", color = Color.White) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, null, tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFFD50000)
                    )
                )
            }
        ) { pad ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(280.dp))
                Text("Welcome, $fullName!", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(16.dp))
                Text(
                    "The Marikina Emergency Team is always ready to respond.",
                    fontSize = 20.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

/* ---------------- DRAWER ---------------- */

@Composable
fun NavigationDrawer(
    navController: NavController,
    authViewModel: AuthViewModel,
    drawerState: DrawerState,
    userId: String,
    onOpenTutorial: () -> Unit
) {
    val scope = rememberCoroutineScope()

    ModalDrawerSheet {
        Column(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = rememberAsyncImagePainter("https://marikina.gov.ph/images/seal1.png"),
                contentDescription = null,
                modifier = Modifier.height(180.dp)
            )

            Spacer(Modifier.height(16.dp))
            Text("MARIKINA EMERGENCY", fontSize = 22.sp, color = Color.Red)

            Spacer(Modifier.height(20.dp))

            DrawerItem("Profile", Icons.Default.Person, "profile/$userId", navController, scope, drawerState)
            DrawerItem("161 Rescue", Icons.Default.LocalHospital, "rescue_161_form", navController, scope, drawerState)
            DrawerItem("BFP", Icons.Default.FireExtinguisher, "bfp_form", navController, scope, drawerState)
            DrawerItem("History", Icons.Default.History, "history", navController, scope, drawerState)

            DrawerItem("Tutorial", Icons.Default.Info, "") {
                onOpenTutorial()
                scope.launch { drawerState.close() }
            }

            Spacer(Modifier.weight(1f))

            DrawerItem("Logout", Icons.Default.ExitToApp, "") {
                authViewModel.logout(navController)
            }
        }
    }
}

@Composable
private fun DrawerItem(
    title: String,
    icon: ImageVector,
    route: String,
    navController: NavController? = null,
    scope: CoroutineScope? = null,
    drawerState: DrawerState? = null,
    action: (() -> Unit)? = null
) {
    NavigationDrawerItem(
        icon = { Icon(icon, null) },
        label = { Text(title) },
        selected = false,
        onClick = {
            action?.invoke()
            if (route.isNotEmpty()) navController?.navigate(route)
            scope?.launch { drawerState?.close() }
        }
    )
}

/* ---------------- TUTORIAL ---------------- */

data class TutorialStep(val title: String, val desc: String, val image: Int)

@Composable
fun TutorialStepsOverlay(onClose: () -> Unit) {
    val steps = listOf(
        TutorialStep("Menu", "Open navigation menu", R.drawable.tut_step1),
        TutorialStep("Profile", "View your profile", R.drawable.tut_step2),
        TutorialStep("Submit", "Send emergency request", R.drawable.tut_step3)
    )

    var index by remember { mutableIntStateOf(0) }
    var zoom by remember { mutableStateOf(false) }

    if (zoom) {
        ZoomImageDialog(steps[index].image) { zoom = false }
    }

    val isTablet = LocalConfiguration.current.screenWidthDp >= 600
    val imgHeight = if (isTablet) 300.dp else 220.dp
    val dialogWidth: Dp? = if (isTablet) 600.dp else null

    Dialog(onDismissRequest = onClose) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .then(if (dialogWidth != null) Modifier.width(dialogWidth) else Modifier.fillMaxWidth())
                    .background(Color.White, shape = MaterialTheme.shapes.large)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(steps[index].title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(Modifier.height(8.dp))

                Image(
                    painter = painterResource(steps[index].image),
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(imgHeight)
                        .pointerInput(Unit) {
                            detectTapGestures { zoom = true }
                        },
                    contentScale = ContentScale.Fit
                )

                Text("Tap image to zoom", fontSize = 12.sp, color = Color.Gray)
                Spacer(Modifier.height(8.dp))
                Text(steps[index].desc, textAlign = TextAlign.Center)

                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                    Button({ if (index > 0) index-- }, enabled = index > 0) { Text("Back") }
                    Text("${index + 1}/${steps.size}")
                    Button({ if (index < steps.lastIndex) index++ else onClose() }) {
                        Text(if (index < steps.lastIndex) "Next" else "Finish")
                    }
                }
            }

            IconButton(onClose, Modifier.align(Alignment.TopEnd)) {
                Icon(Icons.Default.Close, null, tint = Color.White)
            }
        }
    }
}

/* ---------------- ZOOM ---------------- */

@Composable
fun ZoomImageDialog(imageRes: Int, onClose: () -> Unit) {
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    val state = rememberTransformableState { zoom, pan, _ ->
        scale = (scale * zoom).coerceIn(1f, 5f)
        offset += pan
    }

    Dialog(onDismissRequest = onClose) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            Image(
                painter = painterResource(imageRes),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxSize()
                    .transformable(state)
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offset.x,
                        translationY = offset.y
                    ),
                contentScale = ContentScale.Fit
            )

            IconButton(onClose, Modifier.align(Alignment.TopEnd)) {
                Icon(Icons.Default.Close, null, tint = Color.White)
            }
        }
    }
}
