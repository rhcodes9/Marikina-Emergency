package np.com.marikina.application.admin;

import android.app.Activity;

public class MapActivity extends Activity {
}
