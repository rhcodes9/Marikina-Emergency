package np.com.marikina.application

import BfpForm
import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import np.com.marikina.application.admin.AdminHomeScreen
import np.com.marikina.application.admin.DashboardScreen
import np.com.marikina.application.admin.UserAnalyticsPage
import np.com.marikina.application.auth.AuthViewModel
import np.com.marikina.application.pages.LoginPage
import np.com.marikina.application.pages.SignupPage
import np.com.marikina.application.users.HistoryPage
import np.com.marikina.application.users.HomePage
import np.com.marikina.application.users.ProfilePage
import np.com.marikina.application.users.RescueForm

class MainActivity : ComponentActivity() {
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize location client
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        setContent {
            val navController = rememberNavController()
            val authViewModel = AuthViewModel()
            val auth = FirebaseAuth.getInstance()
            val database = FirebaseDatabase.getInstance().reference

            var isAdmin by remember { mutableStateOf<Boolean?>(null) }
            var isLoggedIn by remember { mutableStateOf(auth.currentUser != null) }
            val coroutineScope = rememberCoroutineScope()

            // ✅ No more 10-second countdown: one-time warning only
            LaunchedEffect(true) {
                if (!isLocationEnabled()) {
                    Toast.makeText(
                        this@MainActivity,
                        "Location is turned off. Some features may not work properly.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            // ✅ Fetch user role from Firebase
            LaunchedEffect(auth.currentUser) {
                isLoggedIn = auth.currentUser != null
                isAdmin = null

                auth.currentUser?.let { user ->
                    coroutineScope.launch {
                        try {
                            val snapshot = database.child("users").child(user.uid).get().await()
                            isAdmin = snapshot.child("isAdmin").getValue(Boolean::class.java) ?: false
                        } catch (e: Exception) {
                            isAdmin = false
                        }
                    }
                } ?: run {
                    isAdmin = false
                }
            }

            // ✅ Show loading while waiting for role check
            if (isAdmin == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                // ✅ Navigation routes
                NavHost(navController, startDestination = if (isLoggedIn) "home" else "login") {
                    composable("login") { LoginPage(navController, authViewModel) }
                    composable("signup") { SignupPage(navController, authViewModel) }
                    composable("home") {
                        if (isAdmin == true) {
                            AdminHomeScreen(navController, authViewModel)
                        } else {
                            HomePage(navController, authViewModel)
                        }
                    }
                    composable("profile/{userId}") { backStackEntry ->
                        val userId = backStackEntry.arguments?.getString("userId") ?: ""
                        ProfilePage(navController, userId)
                    }
                    composable("dashboard") { DashboardScreen(navController) }
                    composable("rescue_161_form") { RescueForm(navController) }
                    composable("bfp_form") { BfpForm(navController, authViewModel) }
                    composable("history") { HistoryPage(navController, authViewModel) }
                    composable("user_analy") { UserAnalyticsPage(navController) }
                }
            }
        }
    }

    // ✅ Check if location permissions are granted
    private fun isLocationEnabled(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
    }
}
