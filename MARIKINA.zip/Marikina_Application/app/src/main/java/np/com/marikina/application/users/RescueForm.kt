package np.com.marikina.application.users

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import np.com.bimalkafle.firebaseauthdemoapp.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RescueForm(navController: NavController) {
    val context = LocalContext.current
    val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return
    val database = FirebaseDatabase.getInstance().reference.child("rescue_request")
    val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)

    var fullName by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var contactNumber by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("Fetching location...") }
    var selectedDisaster by remember { mutableStateOf("Select Disaster") }
    var expanded by remember { mutableStateOf(false) }
    var mediaUri by remember { mutableStateOf<Uri?>(null) }
    var isSubmitting by remember { mutableStateOf(false) }

    val disasterTypes = listOf("Flood", "Earthquake", "Medical Emergency", "Accident", "Others")

    // Fetch user details from Firebase
    LaunchedEffect(userId) {
        FirebaseDatabase.getInstance().reference.child("users").child(userId).get()
            .addOnSuccessListener { snapshot ->
                fullName = snapshot.child("fullName").value?.toString() ?: ""
                age = snapshot.child("age").value?.toString() ?: ""
                contactNumber = snapshot.child("contactNumber").value?.toString() ?: "Unknown"
                fetchCurrentLocation(context, fusedLocationClient) { address -> location = address }
            }
    }

    // Image Picker & Camera Capture
    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        mediaUri = uri
        Toast.makeText(context, "Photo Selected", Toast.LENGTH_SHORT).show()
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) {
            Toast.makeText(context, "Photo Captured", Toast.LENGTH_SHORT).show()
        }
    }

    fun submitForm() {
        // Validate inputs before submitting
        if (fullName.isEmpty() || age.isEmpty() || contactNumber.isEmpty() || selectedDisaster == "Select Disaster") {
            Toast.makeText(context, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        isSubmitting = true
        val reportId = database.push().key ?: return
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

        val formData = mapOf(
            "reportId" to reportId,
            "userId" to userId,
            "fullName" to fullName,
            "age" to age,
            "contactNumber" to contactNumber,
            "location" to location,
            "disasterType" to selectedDisaster,
            "category" to "161 Rescue",
            "mediaUrl" to (mediaUri?.toString() ?: "No Image"),
            "timestamp" to timestamp,
            "status" to "Pending"
        )

        database.child(reportId).setValue(formData).addOnCompleteListener { task ->
            isSubmitting = false
            if (task.isSuccessful) {
                Toast.makeText(context, "Rescue Report Sent!", Toast.LENGTH_LONG).show()
                navController.navigate("home") { popUpTo("home") { inclusive = true } }
            } else {
                Toast.makeText(context, "Error submitting report", Toast.LENGTH_LONG).show()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("161 Rescue Form", color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = Color.Red)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // ✅ Display Rescue Image at the top
            Image(
                painter = painterResource(id = R.drawable.rescuer), // Replace with your image resource
                contentDescription = "Rescue Image",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp) // Adjust the height as needed
                    .padding(bottom = 5.dp)
            )

            // Full Name Field
            OutlinedTextField(value = fullName, onValueChange = { fullName = it }, label = { Text("Full Name") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = age, onValueChange = { age = it }, label = { Text("Age") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = contactNumber, onValueChange = { contactNumber = it }, label = { Text("Contact Number") }, modifier = Modifier.fillMaxWidth())

            // Location Field with GPS Button
            OutlinedTextField(
                value = location,
                onValueChange = { location = it },
                label = { Text("Current Address") },
                trailingIcon = {
                    IconButton(onClick = { fetchCurrentLocation(context, fusedLocationClient) { address -> location = address } }) {
                        Icon(Icons.Filled.LocationOn, contentDescription = "Get Location", tint = Color.Red)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            // Disaster Type Dropdown
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = selectedDisaster,
                    onValueChange = {},
                    label = { Text("Type of Disaster") },
                    readOnly = true,
                    trailingIcon = { Icon(Icons.Filled.ArrowDropDown, "Dropdown", Modifier.clickable { expanded = true }) },
                    modifier = Modifier.fillMaxWidth()
                )
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    disasterTypes.forEach { disaster ->
                        DropdownMenuItem(
                            text = { Text(disaster) },
                            onClick = {
                                selectedDisaster = disaster
                                expanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Submit Button
            Button(onClick = { submitForm() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color.Red)) {
                Text("Submit Rescue Report", color = Color.White)
            }
        }
    }
}

// Fetch Current Location Function
@SuppressLint("MissingPermission")
fun fetchCurrentLocation(
    context: Context,
    fusedLocationClient: FusedLocationProviderClient,
    onLocationFetched: (String) -> Unit
) {
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
        Toast.makeText(context, "Location permission is required!", Toast.LENGTH_SHORT).show()
        return
    }

    fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
        if (location != null) {
            val latitude = location.latitude
            val longitude = location.longitude
            val geocoder = android.location.Geocoder(context, Locale.getDefault())
            try {
                val addresses = geocoder.getFromLocation(latitude, longitude, 1)
                if (addresses != null) {
                    if (addresses.isNotEmpty()) {
                        val address = addresses[0]?.getAddressLine(0) ?: "Address not found"
                        onLocationFetched(address)
                    } else {
                        onLocationFetched("Unable to fetch address")
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Error fetching address: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Failed to get location", Toast.LENGTH_SHORT).show()
        }
    }.addOnFailureListener {
        Toast.makeText(context, "Error getting location: ${it.message}", Toast.LENGTH_SHORT).show()
    }
}
