package np.com.marikina.application.admin

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController

@Composable
fun UserAnalyticsPage(navController: NavHostController) {
    // This page will display the user analytics data
    Text("User Analytics Page") // Replace with actual analytics UI
}
