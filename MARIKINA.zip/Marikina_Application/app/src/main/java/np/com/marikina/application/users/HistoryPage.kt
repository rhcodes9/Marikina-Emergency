package np.com.marikina.application.users

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.tasks.await
import np.com.marikina.application.auth.AuthViewModel
import java.text.SimpleDateFormat
import java.util.Locale

// ✅ Report Data Model
data class Report(
    var userId: String = "",
    var fullName: String = "",
    var age: String = "",
    var location: String = "",
    var disasterType: String = "",
    var timestamp: String = "",
    var status: String = "",
    var category: String = "",
    var responderId: String = "",
    var imagePath: String? = null,
    var videoPath: String? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryPage(navController: NavController, authViewModel: AuthViewModel) {
    val context = LocalContext.current
    val auth = FirebaseAuth.getInstance()
    val currentUserId = auth.currentUser?.uid
    val database = FirebaseDatabase.getInstance().reference

    var reports by remember { mutableStateOf<List<Report>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(currentUserId) {
        if (currentUserId != null) {
            val fetchedReports = mutableListOf<Report>()
            try {
                val rescueReportsSnapshot = database.child("rescue_request")
                    .orderByChild("userId")
                    .equalTo(currentUserId)
                    .get().await()

                for (child in rescueReportsSnapshot.children) {
                    val report = child.getValue(Report::class.java)
                    if (report != null) {
                        fetchedReports.add(report)
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Error fetching reports: ${e.message}", Toast.LENGTH_LONG).show()
            }

            reports = fetchedReports.sortedByDescending { it.timestamp }
            isLoading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Rescue Status", color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = Color(0xFFD50000))
            )
        },
        containerColor = Color(0xFFFFEBEE)
    ) { innerPadding ->
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Color(0xFFD50000))
            }
        } else if (reports.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("No reports found", fontSize = 18.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { navController.navigate("history") { popUpTo("history") { inclusive = true } } },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD50000))
                    ) {
                        Text("Refresh", color = Color.White)
                    }
                }
            }
        } else {
            LazyColumn(modifier = Modifier.padding(innerPadding).padding(16.dp)) {
                items(reports) { report -> ReportItem(report) }
            }
        }
    }
}

@Composable
fun ReportItem(report: Report) {
    val context = LocalContext.current

    val statusColor = when (report.status) {
        "Pending" -> Color(0xFFD32F2F)
        "On the way" -> Color(0xFFFFA500)
        "Resolved" -> Color(0xFF2E7D32)
        else -> Color.Gray
    }

    val formattedTimestamp = try {
        val format = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val date = format.parse(report.timestamp)
        val outputFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        outputFormat.format(date)
    } catch (e: Exception) {
        report.timestamp
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clickable {},
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "🚑 ${report.category}",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
            Text(
                text = "Full Name: ${report.fullName}",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Text(text = "📍 Location: ${report.location}", fontSize = 14.sp)
            Text(text = "⚠️ Disaster Type: ${report.disasterType}", fontSize = 14.sp)
            Text(
                text = "🚨 Status: ${report.status}",
                color = statusColor,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Text(
                text = "🕒 Submitted on: $formattedTimestamp",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray
            )

            Spacer(modifier = Modifier.height(8.dp))

            // ✅ "View in Map" Button
            Button(
                onClick = {
                    val location = report.location
                    if (location.isNotEmpty()) {
                        val gmmIntentUri = Uri.parse("geo:0,0?q=$location")
                        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                        mapIntent.setPackage("com.google.android.apps.maps")

                        if (mapIntent.resolveActivity(context.packageManager) != null) {
                            context.startActivity(mapIntent)
                        } else {
                            Toast.makeText(context, "Google Maps is not installed!", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(context, "Location not available", Toast.LENGTH_SHORT).show()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD50000))
            ) {
                Text("📍 View in Map", color = Color.White)
            }
        }
    }
}
