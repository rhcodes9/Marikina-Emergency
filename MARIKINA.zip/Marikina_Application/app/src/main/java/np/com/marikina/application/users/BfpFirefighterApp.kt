package np.com.marikina.application.bfp

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BfpFirefighterApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val fusedLocationClient = remember { LocationServices.getFusedLocationProviderClient(context) }
    val database = FirebaseDatabase.getInstance().reference
    val userId = FirebaseAuth.getInstance().currentUser?.uid
    var status by remember { mutableStateOf("on_the_way") }

    Scaffold(
        topBar = { TopAppBar(title = { Text("BFP Responder App") }) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Update Your Firefighter Location")

            Spacer(modifier = Modifier.height(16.dp))

            // ✅ Update Firefighter Location Button
            Button(onClick = {
                scope.launch {
                    while (true) {
                        updateFirefighterLocation(context, fusedLocationClient, database, userId, status)
                        delay(10000) // Update every 10 seconds
                    }
                }
            }) {
                Text("Start Live Tracking")
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ✅ Change Status (e.g., "Arrived", "Available")
            DropdownMenu(
                expanded = false,
                onDismissRequest = {},
                content = {
                    listOf("on_the_way", "arrived", "available").forEach { option ->
                        DropdownMenuItem(text = { Text(option) }, onClick = { status = option })
                    }
                }
            )
        }
    }
}

// ✅ Update Firefighter Location in Firebase
@SuppressLint("MissingPermission")
fun updateFirefighterLocation(context: Context, fusedLocationClient: FusedLocationProviderClient, database: DatabaseReference, userId: String?, status: String) {
    userId?.let {
        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
            if (location != null) {
                val firefighterLocation = mapOf(
                    "latitude" to location.latitude,
                    "longitude" to location.longitude,
                    "status" to status
                )
                database.child("firefighters_locations").child(it).setValue(firefighterLocation)
                    .addOnSuccessListener { Toast.makeText(context, "Location Updated!", Toast.LENGTH_SHORT).show() }
            }
        }
    }
}
