package np.com.marikina.application.admin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class RespondersMapActivity : ComponentActivity(), OnMapReadyCallback {

    private lateinit var googleMap: GoogleMap
    private var responderMarker: Marker? = null
    private val responderId = "responderId"  // Set this to the responder's unique ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Button(onClick = {
                startTrackingResponderLocation()
            }) {
                Text("Start Tracking Responder")
            }
        }
    }

    private fun startTrackingResponderLocation() {


        // Start listening to the responder's location in Firebase
        val responderRef = FirebaseDatabase.getInstance().getReference("responders").child(responderId)
        responderRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val lat = snapshot.child("lat").getValue(Double::class.java)
                val lng = snapshot.child("lng").getValue(Double::class.java)
                if (lat != null && lng != null) {
                    updateMap(lat, lng)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        })
    }

    private fun updateMap(lat: Double, lng: Double) {
        val responderLatLng = LatLng(lat, lng)
        if (responderMarker == null) {
            // If the marker doesn't exist, create one
            responderMarker = googleMap.addMarker(MarkerOptions().position(responderLatLng).title("Responder"))
        } else {
            // Move the existing marker
            responderMarker?.position = responderLatLng
        }

        // Move camera to the responder's location
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(responderLatLng, 15f))
    }

    override fun onMapReady(googleMap: GoogleMap) {
        this.googleMap = googleMap
    }
}
