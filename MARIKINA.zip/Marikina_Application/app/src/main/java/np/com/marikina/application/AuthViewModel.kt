package np.com.marikina.application.auth

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class AuthViewModel : ViewModel() {

    private val auth = FirebaseAuth.getInstance()
    private val database = FirebaseDatabase.getInstance().reference
    val currentUser = auth.currentUser

    fun signup(
        fullName: String,
        email: String,
        password: String,
        age: String,
        fullAddress: String,
        contactNumber: String,
        // ✅ Added latitude
        // ✅ Added longitude
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit
    ) {
        Log.d("AuthViewModel", "Creating user with email: $email")

        auth.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener { result ->
                val userId = result.user?.uid ?: return@addOnSuccessListener
                val userData = mapOf(
                    "fullName" to fullName,
                    "email" to email,
                    "age" to age,
                    "fullAddress" to fullAddress,
                    "contactNumber" to contactNumber,
                    "isAdmin" to false
                )


                // ✅ Save user data in Firebase Realtime Database
                database.child("users").child(userId).setValue(userData)
                    .addOnSuccessListener {
                        Log.d("AuthViewModel", "User data saved in Firebase")
                        result.user?.sendEmailVerification()
                            ?.addOnSuccessListener {
                                Log.d("AuthViewModel", "Email verification sent")
                                onSuccess() // ✅ Call onSuccess
                            }
                            ?.addOnFailureListener { error ->
                                Log.e("AuthViewModel", "Failed to send verification email: ${error.message}")
                                onFailure("Failed to send verification email. Please check your email address.")
                            }
                    }
                    .addOnFailureListener { error ->
                        Log.e("AuthViewModel", "Failed to save user data: ${error.message}")
                        onFailure("Failed to save user data. Please try again.")
                    }
            }
            .addOnFailureListener { error ->
                Log.e("AuthViewModel", "Signup failed: ${error.message}")
                onFailure(error.message ?: "Signup failed. Please try again.")
            }
    }

    fun logout(navController: NavController) {
        auth.signOut()
        navController.navigate("login") {
            popUpTo("login") { inclusive = true } // ✅ Clear back stack after logout
        }
        Log.d("AuthViewModel", "User logged out")
    }
}
