package np.com.marikina.application;

import android.app.Activity;

public class pages extends Activity {
}
