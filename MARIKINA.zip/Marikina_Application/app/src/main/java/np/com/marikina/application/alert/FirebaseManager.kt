@file:OptIn(ExperimentalMaterial3Api::class)

package np.com.marikina.application.alert

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.os.Build
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.launch
import java.util.Locale

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
@Composable
fun FireBaseManager(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val auth = FirebaseAuth.getInstance()
    val database = FirebaseDatabase.getInstance().reference
    val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)

    var fullName by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var isLocationLoading by remember { mutableStateOf(false) }
    var isSubmitting by remember { mutableStateOf(false) } // ✅ Loading state
    val userId = auth.currentUser?.uid

    var expanded by remember { mutableStateOf(false) }
    val disasterTypes = listOf("Flood", "Fire", "Earthquake", "Medical Emergency", "Accident", "Typhoon", "Search & Rescue", "Chemical Spill", "Other Emergency")
    var selectedDisasterType by remember { mutableStateOf("") }

    // ✅ Fetch User Data from Firebase (Only if user is logged in)
    LaunchedEffect(userId) {
        userId?.let {
            database.child("users").child(it).get().addOnSuccessListener { snapshot ->
                fullName = snapshot.child("fullName").value?.toString() ?: ""
                age = snapshot.child("age").value?.toString() ?: ""
            }
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("161 Rescue Form") }) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OutlinedTextField(value = fullName, onValueChange = { fullName = it }, label = { Text("Full Name") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = age, onValueChange = { age = it }, label = { Text("Age") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())

            Spacer(modifier = Modifier.height(8.dp))

            // ✅ Fixed Disaster Type Dropdown
            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = { expanded = it },
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = selectedDisasterType,
                    onValueChange = {},
                    readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    label = { Text("Type of Disaster/Emergency") },
                    modifier = Modifier.fillMaxWidth()
                )

                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    disasterTypes.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option) },
                            onClick = {
                                selectedDisasterType = option
                                expanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // ✅ Fixed Location Fetching with Loading Indicator
            OutlinedTextField(
                value = location,
                onValueChange = { location = it },
                label = { Text("Current Location (Street, City, Province)") },
                modifier = Modifier.fillMaxWidth(),
                trailingIcon = {
                    if (isLocationLoading) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp))
                    } else {
                        IconButton(onClick = {
                            isLocationLoading = true
                            getCurrentAddress(context, fusedLocationClient) { address ->
                                location = address
                                isLocationLoading = false
                            }
                        }) {
                            Icon(Icons.Filled.LocationOn, contentDescription = "Get Location")
                        }
                    }
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // ✅ Submit Button with Loading State
            Button(
                onClick = {
                    if (fullName.isNotEmpty() && age.isNotEmpty() && location.isNotEmpty() && selectedDisasterType.isNotEmpty()) {
                        scope.launch {
                            isSubmitting = true
                            val formId = database.child("rescue_requests").push().key ?: return@launch
                            val timestamp = System.currentTimeMillis()

                            val formData = mapOf(
                                "userId" to userId,
                                "fullName" to fullName,
                                "age" to age,
                                "disasterType" to selectedDisasterType,
                                "location" to location,
                                "timestamp" to timestamp,
                                "status" to "pending"
                            )

                            database.child("rescue_requests").child(formId).setValue(formData)
                                .addOnSuccessListener {
                                    database.child("notifications").child("admin").push()
                                        .setValue("\uD83D\uDEA8 New 161 Rescue Report: $selectedDisasterType \uD83D\uDEA8 at $location")
                                    Toast.makeText(context, "Rescue Report Sent!", Toast.LENGTH_LONG).show()
                                    navController.navigate("home") { popUpTo("home") { inclusive = true } }
                                }
                                .addOnFailureListener { e ->
                                    Toast.makeText(context, "Failed to submit: ${e.message}", Toast.LENGTH_LONG).show()
                                }
                                .addOnCompleteListener {
                                    isSubmitting = false
                                }
                        }
                    } else {
                        Toast.makeText(context, "Please complete all fields!", Toast.LENGTH_LONG).show()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !isSubmitting
            ) {
                if (isSubmitting) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp))
                } else {
                    Text("Submit Rescue Report")
                }
            }
        }
    }
}

// ✅ Fixed Geocoder for Android 14+
@RequiresApi(Build.VERSION_CODES.TIRAMISU)
@SuppressLint("MissingPermission")
fun getCurrentAddress(context: Context, fusedLocationClient: FusedLocationProviderClient, onAddressFetched: (String) -> Unit) {
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
        fusedLocationClient.lastLocation.addOnSuccessListener { loc: Location? ->
            if (loc != null) {
                val geocoder = Geocoder(context, Locale.getDefault())
                geocoder.getFromLocation(loc.latitude, loc.longitude, 1) { addresses ->
                    val address = addresses?.firstOrNull()?.getAddressLine(0) ?: "Location not found"
                    onAddressFetched(address)
                }
            } else {
                onAddressFetched("Unable to retrieve location")
            }
        }
    } else {
        onAddressFetched("Location permission denied")
    }
}
