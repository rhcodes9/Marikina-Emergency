package np.com.marikina.application.users

import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

data class ProfileUser(
    var userId: String = "",
    var fullName: String = "",
    var age: String = "",
    var fullAddress: String = "",
    var email: String = "",
    var contactNumber: String = "",
    var userType: String = "",
    var profileImageUrl: String = "",
    var dateCreated: String = "",
    var lastUpdated: String = ""
)

data class UserReport(
    val id: String = "",
    val fullName: String = "",
    val location: String = "",
    val category: String = "",
    val status: String = "",
    val timestamp: String = ""
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfilePage(navController: NavController, userId: String) {
    val context = LocalContext.current
    val database = FirebaseDatabase.getInstance().getReference("users").child(userId)
    val reportsRef = FirebaseDatabase.getInstance().getReference("rescue_request")

    val currentUser = FirebaseAuth.getInstance().currentUser
    val isAdmin = currentUser?.email == "admin@gmail.com"

    var user by remember { mutableStateOf<ProfileUser?>(null) }
    val reports = remember { mutableStateListOf<UserReport>() }

    var fullName by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var contact by remember { mutableStateOf("") }

    LaunchedEffect(userId) {
        Log.d("ProfilePage", "userId = $userId")

        if (userId.isBlank()) {
            Toast.makeText(context, "Invalid userId. Cannot load profile.", Toast.LENGTH_LONG).show()
            user = ProfileUser() // show empty but not blank
            return@LaunchedEffect
        }

        // ✅ Fetch user info
        database.get()
            .addOnSuccessListener { snapshot ->
                val userData = snapshot.getValue(ProfileUser::class.java)

                if (userData == null) {
                    Toast.makeText(context, "No user profile found.", Toast.LENGTH_SHORT).show()
                    user = ProfileUser() // prevent blank UI
                    return@addOnSuccessListener
                }

                user = userData

                // Pre-fill editable fields for non-admin
                if (!isAdmin) {
                    fullName = userData.fullName
                    age = userData.age
                    address = userData.fullAddress
                    email = userData.email
                    contact = userData.contactNumber
                }
            }
            .addOnFailureListener {
                Log.e("Firebase", "Error fetching user data: ${it.message}")
                Toast.makeText(context, "Error loading profile: ${it.message}", Toast.LENGTH_LONG).show()
                user = ProfileUser() // prevent blank UI
            }

        // ✅ Fetch reports
        reportsRef.orderByChild("userId").equalTo(userId)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    reports.clear()
                    for (reportSnapshot in snapshot.children) {
                        val report = UserReport(
                            id = reportSnapshot.key ?: "",
                            fullName = reportSnapshot.child("fullName").getValue(String::class.java) ?: "",
                            location = reportSnapshot.child("location").getValue(String::class.java) ?: "",
                            category = reportSnapshot.child("category").getValue(String::class.java) ?: "",
                            status = reportSnapshot.child("status").getValue(String::class.java) ?: "",
                            timestamp = reportSnapshot.child("timestamp").getValue(String::class.java) ?: ""
                        )
                        reports.add(report)
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(context, "Error loading reports: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            })
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Profile Page", color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFD32F2F))
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.AccountBox,
                contentDescription = "Profile Icon",
                tint = Color(0xff444444),
                modifier = Modifier
                    .size(200.dp)
                    .padding(bottom = 16.dp)
            )

            // ✅ No return. Just show loading OR content.
            if (user == null) {
                Text("Loading profile...", color = Color.Gray)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Please wait.", color = Color.Gray)
            } else {
                val userInfo = user!!

                if (isAdmin) {
                    ProfileReadOnlyField("Full Name", userInfo.fullName)
                    ProfileReadOnlyField("Age", userInfo.age)
                    ProfileReadOnlyField("Full Address", userInfo.fullAddress)
                    ProfileReadOnlyField("Email", userInfo.email)
                    ProfileReadOnlyField("Contact Number", userInfo.contactNumber)
                } else {
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("Full Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = age,
                        onValueChange = { age = it },
                        label = { Text("Age") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("Full Address") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = contact,
                        onValueChange = { contact = it },
                        label = { Text("Emergency Contact Number") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            val updatedData = mapOf(
                                "fullName" to fullName,
                                "age" to age,
                                "fullAddress" to address,
                                "email" to email,
                                "contactNumber" to contact,
                                "lastUpdated" to System.currentTimeMillis().toString()
                            )

                            database.updateChildren(updatedData)
                                .addOnSuccessListener {
                                    Toast.makeText(context, "Profile updated successfully!", Toast.LENGTH_SHORT).show()
                                }
                                .addOnFailureListener {
                                    Toast.makeText(context, "Failed to update profile.", Toast.LENGTH_SHORT).show()
                                }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0288D1))
                    ) {
                        Text("Save Changes", color = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
                Text("Report History", fontSize = 18.sp, color = Color.Black)
                Divider(modifier = Modifier.padding(vertical = 8.dp))

                if (reports.isEmpty()) {
                    Text("No reports found", color = Color.Gray)
                } else {
                    LazyColumn {
                        items(reports) { report ->
                            Column(modifier = Modifier.padding(vertical = 6.dp)) {
                                Text("• ${report.category} - ${report.status}", fontSize = 14.sp)
                                Text("  ${report.location}", fontSize = 12.sp, color = Color.Gray)
                                Text("  Submitted: ${report.timestamp}", fontSize = 12.sp, color = Color.Gray)
                                Divider(modifier = Modifier.padding(top = 8.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileReadOnlyField(label: String, value: String) {
    Text(
        "$label: $value",
        fontSize = 14.sp,
        color = Color.DarkGray,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    )
}
